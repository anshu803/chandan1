# ANSHU ETHICALX — Render

Files:
- anshu_ethicalx_v5.py
- requirements.txt
- render.yaml
- README_RENDER.md

Build command:
pip install -r requirements.txt

Start command:
python anshu_ethicalx_v5.py

The bot is configured as a Render Background Worker.
SQLite uses /var/data when the persistent disk is mounted.

The Python file contains editable BOT_TOKEN and ADMIN_ID placeholders.
Never publish a real Telegram bot token publicly. If a token was exposed,
revoke it in BotFather and create a new one.

The project is for defensive cybersecurity education and safe
localhost/self-device/sandbox practice.
